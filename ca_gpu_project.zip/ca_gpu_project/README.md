# GPU-Accelerated Image Processing Using Parallel Cellular Automata

Each pixel is a cellular-automaton cell. One CUDA thread updates one cell from its 3x3 Moore
neighbourhood (8 neighbours + itself). Written in Python with Numba CUDA.

## What it does

| Operation | CA rule |
|---|---|
| `edge` | cell turns on if (max - min) over its 3x3 window exceeds a threshold |
| `binarize` | pointwise threshold (a rule that ignores neighbours) |
| `denoise` | binarize, then N iterations of a majority-vote rule (on if >= 5 of the 9 cells are on) |

Three kernel versions of the same rules, so they can be compared:

- **naive**: each thread reads its 9 pixels from global memory
- **shared**: each block loads a tile + 1-pixel halo into shared memory
- **tuned**: shared-memory tiling, 4 output pixels per thread (halo is a smaller share of each tile)

Iterations ping-pong between two device buffers (a CA must read the *previous* state).
Borders use clamp-to-edge. A SciPy CPU reference is included only to prove correctness and
give a speedup number.

## Files

| File | Purpose |
|---|---|
| `ca_kernels.py` | CUDA kernels, launch logic, timing (CUDA events), GPU info |
| `ops.py` | operation definitions shared by GPU and CPU paths |
| `cpu_reference.py` | CPU reference for correctness and a baseline |
| `test_correctness.py` | every kernel x op x block size must match the CPU exactly |
| `benchmark.py` | sweep size / block / iterations, writes `results.csv` + 3 plots |
| `run_demo.py` | command-line demo |
| `app.py` | Streamlit front end |

## Running (Google Colab or any NVIDIA GPU)

On Colab: Runtime > Change runtime type > GPU, upload the files, then:

```
!pip install numba scipy pillow matplotlib      # usually already installed
!python test_correctness.py                      # run this FIRST
!python run_demo.py --op edge --version shared --compare-cpu
!python benchmark.py
```

Locally: `pip install -r requirements.txt`, then `streamlit run app.py`.

No GPU? `NUMBA_ENABLE_CUDASIM=1 python test_correctness.py --quick` runs the kernels on the
CPU through Numba's simulator (slow; for checking logic only).

## Research questions the benchmark answers

1. Does shared-memory tiling beat global memory, and by how much at each resolution?
2. Which block size is best, and why (occupancy, halo overhead)?
3. Does runtime scale linearly with pixel count, or saturate?
4. How does the number of iterations affect throughput? (ping-pong overhead, launch overhead)

Write up what the plots show. Note that on modern GPUs the L1/L2 caches can make the naive
kernel competitive, so "shared memory is not always faster" is a legitimate, explainable result.

## Status / honesty notes

- Development environment had no GPU. The CPU reference was verified (edge rule matches an
  independent OpenCV implementation, majority rule matches a brute-force loop) and the plotting
  code was tested on synthetic data, but **the CUDA kernels have not been run yet**.
  Run `test_correctness.py` first; if anything fails, the failing case is printed.
- "GPU memory usage" reports the exact image buffer size plus the driver-reported delta, which can
  be rounded by the allocator. It is not a profiler measurement; use Nsight Compute for that.
- Application areas (medical, satellite, industrial) are possible uses, not claims about this project.
