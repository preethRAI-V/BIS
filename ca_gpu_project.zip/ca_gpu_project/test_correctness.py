"""Check every GPU kernel against the CPU reference (exact match required).

    python test_correctness.py

No GPU?  Numba's CUDA simulator runs the same kernels on the CPU (slow, small images only):

    NUMBA_ENABLE_CUDASIM=1 python test_correctness.py --quick
"""
import argparse
import itertools
import sys

import numpy as np

import ca_kernels as ck
from cpu_reference import run_cpu
from ops import OPS


def make_img(h, w, seed):
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    img = 0.5 * (xx / w + yy / h) * 255
    img[(xx - w / 2) ** 2 + (yy - h / 2) ** 2 < (min(h, w) / 4) ** 2] = 200
    noise = rng.random((h, w))
    img[noise < 0.05] = 0
    img[noise > 0.95] = 255
    return img.clip(0, 255).astype(np.uint8)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true", help="fewer cases (for the CUDA simulator)")
    args = ap.parse_args()

    # odd sizes on purpose: they exercise partial blocks and the clamped borders
    sizes = [(37, 53)] if args.quick else [(37, 53), (64, 64), (130, 97)]
    blocks = [(8, 8)] if args.quick else [(8, 8), (16, 16), (32, 8)]
    iters_list = [2] if args.quick else [1, 3]

    fails = total = 0
    for (h, w), op, version, block, iters in itertools.product(sizes, OPS, ck.VERSIONS, blocks, iters_list):
        img = make_img(h, w, seed=h * 1000 + w)
        gpu, _ = ck.run_ca(img, op, iters, version, block)
        cpu, _ = run_cpu(img, op, iters)
        total += 1
        if not np.array_equal(gpu, cpu):
            fails += 1
            bad = int((gpu != cpu).sum())
            print(f"FAIL {op:8s} {version:6s} block={block} iters={iters} size={w}x{h}: {bad} pixels differ")
    print(f"{total - fails}/{total} cases match the CPU reference")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
