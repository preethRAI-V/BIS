"""Command-line demo (works on Colab / any machine with an NVIDIA GPU).

    python run_demo.py --op edge --version shared                 # synthetic test image
    python run_demo.py photo.jpg --op denoise --iters 5 --out result.png --compare-cpu
"""
import argparse

import numpy as np
from PIL import Image

import ca_kernels as ck
from cpu_reference import run_cpu
from ops import OPS


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("image", nargs="?", help="input image (default: synthetic 1024x1024)")
    ap.add_argument("--op", default="edge", choices=OPS)
    ap.add_argument("--version", default="shared", choices=ck.VERSIONS)
    ap.add_argument("--iters", type=int, default=1)
    ap.add_argument("--block", default="16x16")
    ap.add_argument("--param", type=int, default=None, help="threshold (edge: gradient, binarize: level)")
    ap.add_argument("--out", default="output.png")
    ap.add_argument("--compare-cpu", action="store_true")
    a = ap.parse_args()

    if a.image:
        img = np.array(Image.open(a.image).convert("L"))
    else:
        from benchmark import make_test_image
        img = make_test_image(1024)
    bx, by = map(int, a.block.split("x"))

    print("GPU:", ck.gpu_info())
    out, st = ck.run_ca(img, a.op, a.iters, a.version, (bx, by), a.param)
    for k, v in st.items():
        print(f"  {k}: {v:.3f}" if isinstance(v, float) else f"  {k}: {v}")

    if a.compare_cpu:
        ref, cpu_ms = run_cpu(img, a.op, a.iters, a.param)
        print(f"  CPU reference: {cpu_ms:.2f} ms  ->  GPU kernel speedup {cpu_ms / st['kernel_ms']:.1f}x")
        print("  output matches CPU:", bool(np.array_equal(out, ref)))

    Image.fromarray(np.hstack([img, out])).save(a.out)
    print("saved input | output side by side to", a.out)


if __name__ == "__main__":
    main()
