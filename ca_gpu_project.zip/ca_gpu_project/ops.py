"""Operation definitions shared by the GPU and CPU code paths (no GPU imports here)."""

# edge     : Moore-neighbourhood edge rule (max - min over the 3x3 window > threshold)
# binarize : pointwise threshold (a CA rule that ignores its neighbours)
# denoise  : binarize, then `iters` passes of the majority-vote CA rule
# majority : only the iterated majority-vote rule (used by the benchmark)
OPS = ("edge", "binarize", "denoise", "majority")

DEFAULT_PARAM = {"edge": 30, "binarize": 128, "denoise": 128, "majority": 128}


def build_passes(op, iters=1, param=None):
    """Return the list of (rule_name, parameter) passes that implement an operation."""
    if op not in OPS:
        raise ValueError(f"unknown op {op!r}; choose from {OPS}")
    p = DEFAULT_PARAM[op] if param is None else int(param)
    iters = max(1, int(iters))
    if op == "edge":
        return [("edge", p)] * iters
    if op == "binarize":
        return [("binarize", p)]
    if op == "denoise":
        return [("binarize", p)] + [("majority", 0)] * iters
    return [("majority", 0)] * iters
