"""Cellular-automata image kernels for CUDA (Numba).

Every cell (pixel) is updated by one GPU thread from its 3x3 Moore neighbourhood.
Three implementations of the same rules are provided so they can be compared:

  naive  : each thread reads its 9 pixels straight from global memory
  shared : each block cooperatively loads a (tile + 1-pixel halo) into shared memory
  tuned  : shared-memory tiling, and each thread computes `rpt` output pixels
           (bigger tile => the halo is a smaller fraction of the loaded data)

A CA must update all cells from the *previous* state, so iterations ping-pong
between two device buffers.  Borders use replicate (clamp-to-edge) handling.
"""
import math
import time

import numpy as np
from numba import cuda

from ops import build_passes

VERSIONS = ("naive", "shared", "tuned")


# --------------------------------------------------------------------------
# CA transition rules.  Inputs: centre pixel, min / max of the 3x3 window,
# number of "on" (> 127) pixels in the window, and a rule parameter.
# --------------------------------------------------------------------------
@cuda.jit(device=True)
def rule_edge(c, mn, mx, cnt, p):
    return 255 if (mx - mn) > p else 0


@cuda.jit(device=True)
def rule_binarize(c, mn, mx, cnt, p):
    return 255 if c > p else 0


@cuda.jit(device=True)
def rule_majority(c, mn, mx, cnt, p):
    return 255 if cnt >= 5 else 0


RULES = {"edge": rule_edge, "binarize": rule_binarize, "majority": rule_majority}


@cuda.jit(device=True)
def stats3x3(a, r, c):
    """min, max and on-count of the 3x3 window centred at a[r, c]."""
    mn = 255
    mx = 0
    cnt = 0
    for dy in range(-1, 2):
        for dx in range(-1, 2):
            v = a[r + dy, c + dx]
            if v < mn:
                mn = v
            if v > mx:
                mx = v
            if v > 127:
                cnt += 1
    return mn, mx, cnt


# --------------------------------------------------------------------------
# Kernel factory (block size / rule are compile-time constants)
# --------------------------------------------------------------------------
_kernel_cache = {}


def get_kernel(version, rule, bx, by, rpt=4):
    key = (version, rule, bx, by, rpt if version == "tuned" else 0)
    if key in _kernel_cache:
        return _kernel_cache[key]
    rule_fn = RULES[rule]

    if version == "naive":

        @cuda.jit
        def kern(src, dst, p):
            x, y = cuda.grid(2)
            h, w = src.shape
            if x >= w or y >= h:
                return
            mn = 255
            mx = 0
            cnt = 0
            for dy in range(-1, 2):
                yy = min(max(y + dy, 0), h - 1)
                for dx in range(-1, 2):
                    xx = min(max(x + dx, 0), w - 1)
                    v = src[yy, xx]
                    if v < mn:
                        mn = v
                    if v > mx:
                        mx = v
                    if v > 127:
                        cnt += 1
            dst[y, x] = rule_fn(src[y, x], mn, mx, cnt, p)

    elif version == "shared":
        TH = by + 2
        TW = bx + 2

        @cuda.jit
        def kern(src, dst, p):
            tile = cuda.shared.array((TH, TW), np.uint8)
            h, w = src.shape
            tx = cuda.threadIdx.x
            ty = cuda.threadIdx.y
            x = cuda.blockIdx.x * bx + tx
            y = cuda.blockIdx.y * by + ty
            x0 = cuda.blockIdx.x * bx - 1
            y0 = cuda.blockIdx.y * by - 1
            # cooperative, coalesced load of tile + halo (clamped at borders)
            tid = ty * bx + tx
            for i in range(tid, TH * TW, bx * by):
                ly = i // TW
                lx = i % TW
                gy = min(max(y0 + ly, 0), h - 1)
                gx = min(max(x0 + lx, 0), w - 1)
                tile[ly, lx] = src[gy, gx]
            cuda.syncthreads()  # every thread reaches this (no early return above)
            if x < w and y < h:
                mn, mx, cnt = stats3x3(tile, ty + 1, tx + 1)
                dst[y, x] = rule_fn(tile[ty + 1, tx + 1], mn, mx, cnt, p)

    elif version == "tuned":
        TH = by * rpt + 2
        TW = bx + 2

        @cuda.jit
        def kern(src, dst, p):
            tile = cuda.shared.array((TH, TW), np.uint8)
            h, w = src.shape
            tx = cuda.threadIdx.x
            ty = cuda.threadIdx.y
            x = cuda.blockIdx.x * bx + tx
            ybase = cuda.blockIdx.y * (by * rpt)
            x0 = cuda.blockIdx.x * bx - 1
            y0 = ybase - 1
            tid = ty * bx + tx
            for i in range(tid, TH * TW, bx * by):
                ly = i // TW
                lx = i % TW
                gy = min(max(y0 + ly, 0), h - 1)
                gx = min(max(x0 + lx, 0), w - 1)
                tile[ly, lx] = src[gy, gx]
            cuda.syncthreads()
            # each thread handles rows ty, ty+by, ty+2*by, ... (keeps warps coalesced)
            for r in range(rpt):
                ly = ty + r * by
                y = ybase + ly
                if x < w and y < h:
                    mn, mx, cnt = stats3x3(tile, ly + 1, tx + 1)
                    dst[y, x] = rule_fn(tile[ly + 1, tx + 1], mn, mx, cnt, p)
    else:
        raise ValueError(f"unknown version {version!r}; choose from {VERSIONS}")

    _kernel_cache[key] = kern
    return kern


def launch_config(version, w, h, bx, by, rpt=4):
    rows_per_block = by * rpt if version == "tuned" else by
    return (math.ceil(w / bx), math.ceil(h / rows_per_block)), (bx, by)


# --------------------------------------------------------------------------
# Host-side driver
# --------------------------------------------------------------------------
_warmed = set()


def _warm_up(version, rules, bx, by, rpt):
    """Trigger JIT compilation outside the timed region."""
    dummy_a = cuda.to_device(np.zeros((64, 64), np.uint8))
    dummy_b = cuda.device_array_like(dummy_a)
    for rule in rules:
        key = (version, rule, bx, by, rpt)
        if key in _warmed:
            continue
        grid, blk = launch_config(version, 64, 64, bx, by, rpt)
        get_kernel(version, rule, bx, by, rpt)[grid, blk](dummy_a, dummy_b, 0)
        _warmed.add(key)
    cuda.synchronize()


def run_ca(img, op="edge", iters=1, version="shared", block=(16, 16), param=None, rpt=4):
    """Run a CA operation on the GPU.

    img   : 2-D uint8 array (grayscale)
    Returns (output_image, stats_dict).  kernel_ms is measured with CUDA events and
    covers only the kernel passes (not host<->device copies, not JIT compilation).
    """
    img = np.ascontiguousarray(img, dtype=np.uint8)
    h, w = img.shape
    bx, by = block
    passes = build_passes(op, iters, param)
    _warm_up(version, sorted({r for r, _ in passes}), bx, by, rpt)

    cuda.synchronize()
    try:
        free0, total = cuda.current_context().get_memory_info()
    except Exception:
        free0, total = None, None

    t0 = time.perf_counter()
    d_src = cuda.to_device(img)
    d_dst = cuda.device_array_like(d_src)
    cuda.synchronize()
    h2d_ms = (time.perf_counter() - t0) * 1000.0

    try:
        free1, _ = cuda.current_context().get_memory_info()
    except Exception:
        free1 = None

    grid, blk = launch_config(version, w, h, bx, by, rpt)
    start, end = cuda.event(), cuda.event()
    start.record()
    for rule, p in passes:
        get_kernel(version, rule, bx, by, rpt)[grid, blk](d_src, d_dst, p)
        d_src, d_dst = d_dst, d_src  # ping-pong: result is always in d_src
    end.record()
    end.synchronize()
    kernel_ms = cuda.event_elapsed_time(start, end)

    t0 = time.perf_counter()
    out = d_src.copy_to_host()
    d2h_ms = (time.perf_counter() - t0) * 1000.0

    n_passes = len(passes)
    stats = {
        "width": w,
        "height": h,
        "version": version,
        "block": f"{bx}x{by}",
        "grid": f"{grid[0]}x{grid[1]}",
        "threads_launched_per_pass": grid[0] * grid[1] * bx * by,
        "passes": n_passes,
        "kernel_ms": kernel_ms,
        "ms_per_pass": kernel_ms / n_passes,
        "h2d_ms": h2d_ms,
        "d2h_ms": d2h_ms,
        "mpix_per_s": (w * h * n_passes) / (kernel_ms / 1000.0) / 1e6 if kernel_ms > 0 else float("inf"),
        "buffer_bytes": 2 * img.nbytes,
        "gpu_mem_used_by_buffers_mb": (free0 - free1) / 2**20 if free0 is not None and free1 is not None else None,
        "gpu_mem_total_mb": total / 2**20 if total is not None else None,
    }
    return out, stats


def gpu_info():
    dev = cuda.get_current_device()
    name = dev.name.decode() if isinstance(dev.name, bytes) else dev.name
    info = {"name": name, "compute_capability": "%d.%d" % dev.compute_capability}
    try:
        info["multiprocessors"] = dev.MULTIPROCESSOR_COUNT
    except Exception:
        pass
    return info
