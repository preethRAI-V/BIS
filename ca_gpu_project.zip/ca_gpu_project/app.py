"""Streamlit front end:  streamlit run app.py"""
import numpy as np
import streamlit as st
from PIL import Image

from ops import DEFAULT_PARAM

st.set_page_config(page_title="GPU Cellular Automata", layout="wide")
st.title("GPU-Accelerated Image Processing Using Parallel Cellular Automata")

try:
    from numba import cuda

    import ca_kernels as ck

    GPU_OK = cuda.is_available()
    ERR = "No CUDA-capable GPU was found."
except Exception as e:  # numba missing or driver problem
    GPU_OK, ERR = False, f"CUDA / Numba could not be loaded: {e}"

if not GPU_OK:
    st.error(ERR + " Run this on a machine with an NVIDIA GPU (or Colab with a GPU runtime).")
    st.stop()

from cpu_reference import run_cpu

OPERATIONS = {
    "Edge detection": "edge",
    "Binary transformation": "binarize",
    "Noise reduction (majority CA)": "denoise",
}

with st.sidebar:
    st.header("Settings")
    file = st.file_uploader("Upload image", type=["png", "jpg", "jpeg", "bmp", "tif", "tiff"])
    label = st.selectbox("Operation", list(OPERATIONS))
    op = OPERATIONS[label]
    version = st.selectbox("Kernel version", ck.VERSIONS, index=1,
                           help="naive = global memory, shared = tiled shared memory, tuned = tiled + 4 outputs/thread")
    block = st.selectbox("Thread block", ["8x8", "16x16", "32x8", "32x32"], index=1)
    iters = st.slider("Iterations", 1, 100, 5 if op == "denoise" else 1,
                      help="Number of CA update steps (edge detection normally uses 1)")
    param = st.slider("Threshold", 0, 255, DEFAULT_PARAM[op],
                      help="Edge: min max-min difference. Binary / denoise: brightness cut-off.")
    side = st.selectbox("Resize longest side to", ["original", 512, 1024, 2048, 4096], index=0)
    compare = st.checkbox("Compare with CPU reference", value=True)
    run = st.button("Run on GPU", type="primary")

info = ck.gpu_info()
st.caption(f"GPU: {info['name']} (compute capability {info['compute_capability']})")

if file is None:
    st.info("Upload an image in the sidebar to begin.")
    st.stop()

img = Image.open(file).convert("L")
if side != "original":
    s = int(side) / max(img.size)
    img = img.resize((max(1, round(img.width * s)), max(1, round(img.height * s))), Image.LANCZOS)
arr = np.array(img)

if run:
    bx, by = map(int, block.split("x"))
    out, stats = ck.run_ca(arr, op, iters, version, (bx, by), param)

    c1, c2 = st.columns(2)
    c1.image(arr, caption=f"Input ({arr.shape[1]}x{arr.shape[0]})", use_container_width=True, clamp=True)
    c2.image(out, caption=f"Output: {label}", use_container_width=True, clamp=True)

    m = st.columns(4)
    m[0].metric("Kernel time", f"{stats['kernel_ms']:.3f} ms")
    m[1].metric("Passes (iterations)", stats["passes"])
    m[2].metric("Throughput", f"{stats['mpix_per_s']:.0f} Mpix/s")
    m[3].metric("Image buffers on GPU", f"{stats['buffer_bytes'] / 2**20:.1f} MB")

    rows = {
        "Kernel version": stats["version"],
        "Block / grid": f"{stats['block']} / {stats['grid']}",
        "Threads launched per pass": f"{stats['threads_launched_per_pass']:,}",
        "ms per pass": f"{stats['ms_per_pass']:.4f}",
        "Host to device copy": f"{stats['h2d_ms']:.2f} ms",
        "Device to host copy": f"{stats['d2h_ms']:.2f} ms",
    }
    if compare:
        ref, cpu_ms = run_cpu(arr, op, iters, param)
        rows["CPU reference (SciPy)"] = f"{cpu_ms:.2f} ms"
        rows["Kernel speedup vs CPU"] = f"{cpu_ms / stats['kernel_ms']:.1f}x (kernel only, excludes copies)"
        rows["Output matches CPU"] = "yes" if np.array_equal(out, ref) else "NO - please report"
    with st.expander("Performance statistics", expanded=True):
        st.table({"Metric": list(rows), "Value": [str(v) for v in rows.values()]})
else:
    st.image(arr, caption="Input", width=480, clamp=True)
    st.write("Choose settings and press **Run on GPU**.")
