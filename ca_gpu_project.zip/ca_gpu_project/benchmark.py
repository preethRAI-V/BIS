"""Benchmark the three kernel versions across image size, block size and iterations.

    python benchmark.py                      # full sweep, writes results.csv + 3 PNG plots
    python benchmark.py --sizes 512 1024 --iters 1 10 --repeats 3
    python benchmark.py --plot-only results.csv

Kernel time is measured with CUDA events (kernel passes only), median of --repeats runs.
"""
import argparse
import csv
import os
import statistics

import numpy as np

from ops import OPS, build_passes

# Okabe-Ito colours, assigned in a fixed order: naive, shared, tuned.
COLORS = {"naive": "#0072B2", "shared": "#E69F00", "tuned": "#009E73"}
VERSIONS = ("naive", "shared", "tuned")


def make_test_image(n, seed=0):
    """Square grayscale test image: smooth gradient + discs + salt-and-pepper noise."""
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float32)
    img = 0.5 * (xx + yy) / n * 255
    for _ in range(12):
        cx, cy, r = rng.uniform(0, n, 2).tolist() + [rng.uniform(0.03, 0.12) * n]
        img[(xx - cx) ** 2 + (yy - cy) ** 2 < r * r] = rng.uniform(0, 255)
    noise = rng.random((n, n))
    img[noise < 0.03] = 0
    img[noise > 0.97] = 255
    return img.clip(0, 255).astype(np.uint8)


def run_benchmark(args):
    import ca_kernels as ck

    print("GPU:", ck.gpu_info())
    rows = []
    for n in args.sizes:
        img = make_test_image(n)
        for version in VERSIONS:
            for bx, by in (tuple(map(int, b.split("x"))) for b in args.blocks):
                for iters in args.iters:
                    times = [
                        ck.run_ca(img, args.op, iters, version, (bx, by))[1]["kernel_ms"]
                        for _ in range(args.repeats)
                    ]
                    ms = statistics.median(times)
                    passes = len(build_passes(args.op, iters))
                    rows.append(
                        dict(op=args.op, size=n, version=version, bx=bx, by=by, iters=iters,
                             kernel_ms=round(ms, 4),
                             mpix_per_s=round(n * n * passes / (ms / 1000) / 1e6, 1))
                    )
                    print(f"{n:5d}^2 {version:6s} {bx}x{by:<3d} it={iters:<4d} {ms:9.3f} ms")
    with open(args.csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print("wrote", args.csv)


def make_plots(csv_path, outdir="."):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    with open(csv_path) as f:
        rows = list(csv.DictReader(f))
    ms = {}
    for r in rows:
        ms[(int(r["size"]), r["version"], int(r["bx"]), int(r["by"]), int(r["iters"]))] = float(r["kernel_ms"])
    sizes = sorted({k[0] for k in ms})
    blocks = sorted({(k[2], k[3]) for k in ms})
    iters_all = sorted({k[4] for k in ms})
    block = (16, 16) if (16, 16) in blocks else blocks[0]
    iters = 10 if 10 in iters_all else iters_all[len(iters_all) // 2]
    op = rows[0].get("op", "")

    def style(ax):
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
        ax.grid(True, axis="y", color="#e5e5e5", linewidth=0.8)
        ax.set_axisbelow(True)

    # 1) time vs resolution
    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    for v in VERSIONS:
        ys = [ms.get((n, v, *block, iters)) for n in sizes]
        ax.plot(sizes, ys, marker="o", markersize=6, linewidth=2, color=COLORS[v], label=v)
    ax.set_xscale("log", base=2)
    ax.set_yscale("log")
    ax.set_xticks(sizes)
    ax.set_xticklabels([f"{n}²" for n in sizes])
    ax.set_xlabel("Image size (pixels)")
    ax.set_ylabel("Kernel time (ms)")
    ax.set_title(f"Kernel time vs resolution ({op}, block {block[0]}x{block[1]}, {iters} iterations)", fontsize=10)
    ax.legend(frameon=False)
    style(ax)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "plot_time_vs_size.png"), dpi=160)
    plt.close(fig)

    # 2) speedup over naive
    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    for v in ("shared", "tuned"):
        ys = [ms[(n, "naive", *block, iters)] / ms[(n, v, *block, iters)] for n in sizes]
        ax.plot(sizes, ys, marker="o", markersize=6, linewidth=2, color=COLORS[v], label=f"{v} vs naive")
    ax.axhline(1.0, color="#888888", linewidth=1, linestyle="--")
    ax.set_xscale("log", base=2)
    ax.set_xticks(sizes)
    ax.set_xticklabels([f"{n}²" for n in sizes])
    ax.set_xlabel("Image size (pixels)")
    ax.set_ylabel("Speedup over naive (x)")
    ax.set_title(f"Speedup over naive kernel (block {block[0]}x{block[1]}, {iters} iterations)", fontsize=10)
    ax.legend(frameon=False)
    style(ax)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "plot_speedup.png"), dpi=160)
    plt.close(fig)

    # 3) time vs block size at the largest image
    n = sizes[-1]
    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    width = 0.26
    x = np.arange(len(blocks))
    for i, v in enumerate(VERSIONS):
        ys = [ms.get((n, v, bx, by, iters), np.nan) for bx, by in blocks]
        ax.bar(x + (i - 1) * width, ys, width * 0.92, color=COLORS[v], label=v)
    ax.set_xticks(x)
    ax.set_xticklabels([f"{bx}x{by}" for bx, by in blocks])
    ax.set_xlabel("Thread block size")
    ax.set_ylabel("Kernel time (ms)")
    ax.set_title(f"Kernel time vs block size ({n}², {iters} iterations)", fontsize=10)
    ax.legend(frameon=False, ncol=3, loc="upper center", bbox_to_anchor=(0.5, -0.2))
    style(ax)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "plot_time_vs_block.png"), dpi=160)
    plt.close(fig)
    print("wrote plot_time_vs_size.png, plot_speedup.png, plot_time_vs_block.png in", outdir)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--op", default="majority", choices=OPS)
    ap.add_argument("--sizes", type=int, nargs="+", default=[512, 1024, 2048, 4096])
    ap.add_argument("--blocks", nargs="+", default=["8x8", "16x16", "32x8", "32x32"])
    ap.add_argument("--iters", type=int, nargs="+", default=[1, 10, 100])
    ap.add_argument("--repeats", type=int, default=5)
    ap.add_argument("--csv", default="results.csv")
    ap.add_argument("--plot-only", metavar="CSV")
    args = ap.parse_args()
    if args.plot_only:
        make_plots(args.plot_only)
    else:
        run_benchmark(args)
        make_plots(args.csv)
