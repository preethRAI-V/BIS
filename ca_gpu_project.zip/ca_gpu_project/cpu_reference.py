"""CPU reference implementation.

Used only to (1) prove the GPU kernels are correct and (2) give a speedup number.
Border handling is 'replicate' (clamp to edge), matching the GPU kernels.
"""
import time

import numpy as np
from scipy import ndimage

from ops import build_passes


def _edge(img, p):
    mx = ndimage.maximum_filter(img, size=3, mode="nearest").astype(np.int16)
    mn = ndimage.minimum_filter(img, size=3, mode="nearest").astype(np.int16)
    return np.where(mx - mn > p, 255, 0).astype(np.uint8)


def _binarize(img, p):
    return np.where(img > p, 255, 0).astype(np.uint8)


def _majority(img, _p):
    on = (img > 127).astype(np.int32)
    cnt = ndimage.convolve(on, np.ones((3, 3), dtype=np.int32), mode="nearest")
    return np.where(cnt >= 5, 255, 0).astype(np.uint8)


_RULES = {"edge": _edge, "binarize": _binarize, "majority": _majority}


def run_cpu(img, op, iters=1, param=None):
    """Return (output_image, elapsed_ms)."""
    img = np.ascontiguousarray(img, dtype=np.uint8)
    t0 = time.perf_counter()
    cur = img
    for rule, p in build_passes(op, iters, param):
        cur = _RULES[rule](cur, p)
    return cur, (time.perf_counter() - t0) * 1000.0
